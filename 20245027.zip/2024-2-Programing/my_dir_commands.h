#include "header.h"

#ifndef __COMMANDS2_H__
#	define __COMMANDS2_H__ 1

/* functions */
void mymkfs(char **commands);
void mytouch(char **commands);
void mymkdir(char **commands);
void myrmdir(char **commands);
void myls(char **commands);
void mypwd(char **commands);
void mycd(char **commands);
void mytree(char **commands);
void myrm(char **commands);
void mymv(char **commands);

#endif
