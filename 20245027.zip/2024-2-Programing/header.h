#ifndef header
#define header 1

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdbool.h>

#include "system/file_system.h"
#include "system/io_stream.h"
#include "system/data_struct.h"

#endif
